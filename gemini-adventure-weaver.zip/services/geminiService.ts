
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GameStateFromAI } from '../types';

const GEMINI_MODEL_TEXT = 'gemini-2.5-flash-preview-04-17';
const IMAGEN_MODEL_IMAGE = 'imagen-3.0-generate-002';

if (!process.env.API_KEY) {
  // This check is more for development; in production, the key is assumed to be set.
  // The app will show an error message in the UI if API_KEY is missing.
  console.error("API_KEY environment variable is not set. The application will not function correctly.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "MISSING_API_KEY" });

function parseAIResponse(responseText: string): GameStateFromAI | null {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[1]) {
    jsonStr = match[1].trim();
  }

  try {
    const parsed = JSON.parse(jsonStr);
    // Basic validation
    if (parsed && typeof parsed.sceneDescription === 'string' &&
        typeof parsed.imagePrompt === 'string' &&
        Array.isArray(parsed.choices) &&
        typeof parsed.gameOver === 'boolean') {
      return parsed as GameStateFromAI;
    }
    console.error("Parsed JSON does not match GameStateFromAI structure:", parsed);
    return null;
  } catch (e) {
    console.error("Failed to parse JSON response from AI:", e, "Raw response:", responseText);
    return null;
  }
}

export const getInitialScene = async (theme: string): Promise<GameStateFromAI | null> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is not configured. Please set the API_KEY environment variable.");
  }
  const prompt = `
    Start a new text adventure game with the theme: "${theme}".
    Describe the opening scene vividly and engagingly.
    Provide a compelling image prompt (max 15 words, focus on key visual elements) relevant to this scene. This prompt will be used to generate an image.
    Offer 2-4 distinct choices for the player, each as a short action-oriented phrase.
    The game should not be over at the start.

    Respond ONLY in JSON format with the following structure, no other text or markdown:
    {
      "sceneDescription": "string",
      "imagePrompt": "string",
      "choices": ["string", "string", ...],
      "gameOver": false,
      "gameOverMessage": null
    }
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7, 
      },
    });
    return parseAIResponse(response.text);
  } catch (error) {
    console.error("Error getting initial scene from Gemini:", error);
    throw error;
  }
};

export const getNextScene = async (
  currentSceneDescription: string,
  playerChoice: string,
  storyHistory: string[] // Array of past scene descriptions
): Promise<GameStateFromAI | null> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is not configured. Please set the API_KEY environment variable.");
  }
  const historyContext = storyHistory.slice(-3).map((event, index) => `${index + 1}. ${event}`).join("\n");

  const prompt = `
    The player is in a text adventure game.
    Story context (most recent events first):
    ${historyContext}

    Current situation: "${currentSceneDescription}"
    Player's action: "${playerChoice}"

    Continue the story based on this action.
    Describe the new scene vividly and engagingly.
    Provide a compelling image prompt (max 15 words, focus on key visual elements) for this new scene.
    Offer 2-4 distinct choices for the player for the new scene.
    Determine if this action leads to a game over state (e.g., death, victory, significant unresolved ending). If so, set gameOver to true and provide a concise gameOverMessage.

    Respond ONLY in JSON format with the following structure, no other text or markdown:
    {
      "sceneDescription": "string",
      "imagePrompt": "string",
      "choices": ["string", "string", ...],
      "gameOver": boolean,
      "gameOverMessage": "string (null if not game over)"
    }
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });
    return parseAIResponse(response.text);
  } catch (error) {
    console.error("Error getting next scene from Gemini:", error);
    throw error;
  }
};

export const generateImage = async (prompt: string): Promise<string | null> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is not configured. Please set the API_KEY environment variable.");
  }
  try {
    const response = await ai.models.generateImages({
      model: IMAGEN_MODEL_IMAGE,
      prompt: prompt,
      config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    }
    return null;
  } catch (error) {
    console.error("Error generating image with Imagen:", error);
    // Don't throw, allow game to continue without image if needed
    return null; 
  }
};
