
import React, { useState } from 'react';

interface GameStartScreenProps {
  onStartGame: (theme: string) => void;
  isLoading: boolean;
}

const themes = [
  "Classic Fantasy Quest",
  "Sci-Fi Space Exploration",
  "Cyberpunk Detective Mystery",
  "Post-Apocalyptic Survival",
  "Haunted Mansion Investigation",
  "Deep Sea Adventure"
];

const GameStartScreen: React.FC<GameStartScreenProps> = ({ onStartGame, isLoading }) => {
  const [selectedTheme, setSelectedTheme] = useState<string>(themes[0]);
  const [customTheme, setCustomTheme] = useState<string>("");
  const [useCustomTheme, setUseCustomTheme] = useState<boolean>(false);

  const handleStart = () => {
    onStartGame(useCustomTheme && customTheme.trim() ? customTheme.trim() : selectedTheme);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-gray-900 to-purple-900">
      <div className="bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-lg text-center">
        <h1 className="text-5xl font-bold text-purple-400 mb-3">Gemini Adventure Weaver</h1>
        <p className="text-slate-300 mb-8 text-lg">Craft your unique story. Choose a theme or enter your own!</p>
        
        <div className="mb-6">
          <label htmlFor="theme-select" className="block text-sm font-medium text-slate-400 mb-2">Select a Theme:</label>
          <select
            id="theme-select"
            value={selectedTheme}
            onChange={(e) => {
              setSelectedTheme(e.target.value);
              setUseCustomTheme(false);
            }}
            disabled={isLoading || useCustomTheme}
            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-md text-slate-200 focus:ring-purple-500 focus:border-purple-500"
          >
            {themes.map(theme => <option key={theme} value={theme}>{theme}</option>)}
          </select>
        </div>

        <div className="flex items-center justify-center my-4">
            <span className="h-px bg-gray-600 flex-grow"></span>
            <span className="px-3 text-gray-500">OR</span>
            <span className="h-px bg-gray-600 flex-grow"></span>
        </div>
        
        <div className="mb-6">
          <label htmlFor="custom-theme" className="block text-sm font-medium text-slate-400 mb-2">Enter Custom Theme:</label>
          <input
            type="text"
            id="custom-theme"
            value={customTheme}
            onChange={(e) => {
              setCustomTheme(e.target.value);
              if (e.target.value.trim()) {
                setUseCustomTheme(true);
              } else {
                setUseCustomTheme(false);
              }
            }}
            placeholder="e.g., A journey to the center of the Earth"
            disabled={isLoading}
            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-md text-slate-200 focus:ring-purple-500 focus:border-purple-500"
          />
        </div>

        <button
          onClick={handleStart}
          disabled={isLoading || (!useCustomTheme && !selectedTheme) || (useCustomTheme && !customTheme.trim())}
          className="w-full bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-lg text-xl shadow-lg transition duration-150 transform hover:scale-105"
        >
          {isLoading ? 'Weaving...' : 'Start Adventure'}
        </button>
      </div>
       <footer className="mt-12 text-center text-sm text-gray-500">
        <p>Powered by Google Gemini & Imagen</p>
        <p>Ensure your API_KEY is configured.</p>
      </footer>
    </div>
  );
};

export default GameStartScreen;
