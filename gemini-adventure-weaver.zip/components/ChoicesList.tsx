
import React from 'react';
import ChoiceButton from './ChoiceButton';

interface ChoicesListProps {
  choices: string[];
  onChoiceSelected: (choice: string) => void;
  disabled?: boolean;
}

const ChoicesList: React.FC<ChoicesListProps> = ({ choices, onChoiceSelected, disabled }) => {
  if (!choices || choices.length === 0) {
    return <p className="text-center text-gray-500 italic my-4">No choices available at this moment.</p>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
      {choices.map((choice, index) => (
        <ChoiceButton
          key={index}
          text={choice}
          onClick={() => onChoiceSelected(choice)}
          disabled={disabled}
        />
      ))}
    </div>
  );
};

export default ChoicesList;
