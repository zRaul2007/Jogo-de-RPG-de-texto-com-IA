
import React from 'react';

interface GameOverScreenProps {
  message: string | null;
  onRestart: () => void;
}

const GameOverScreen: React.FC<GameOverScreenProps> = ({ message, onRestart }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-gray-900 to-red-900 text-center">
      <div className="bg-gray-800 p-8 md:p-12 rounded-xl shadow-2xl w-full max-w-lg">
        <h2 className="text-4xl font-bold text-red-400 mb-6">Game Over</h2>
        <p className="text-slate-300 text-lg mb-8">
          {message || "Your adventure has come to an end."}
        </p>
        <button
          onClick={onRestart}
          className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold py-3 px-8 rounded-lg text-xl shadow-lg transition duration-150 transform hover:scale-105"
        >
          Play Again?
        </button>
      </div>
    </div>
  );
};

export default GameOverScreen;
