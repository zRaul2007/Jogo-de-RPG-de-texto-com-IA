
import React from 'react';

interface SceneDisplayProps {
  description: string;
}

const SceneDisplay: React.FC<SceneDisplayProps> = ({ description }) => {
  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg mb-6">
      <p className="text-lg leading-relaxed text-slate-300 whitespace-pre-wrap">{description}</p>
    </div>
  );
};

export default SceneDisplay;
